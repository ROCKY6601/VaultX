package com.vaultx.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.Screen
import com.vaultx.app.VaultViewModel
import com.vaultx.app.data.Entry
import com.vaultx.app.data.EntryType

@Composable
fun HomeScreen(vm: VaultViewModel) {
    val all = vm.entries
    val q = vm.query.trim().lowercase()
    val list = remember(all, q, vm.filter) {
        all.filter { e ->
            (vm.filter == null || e.type == vm.filter) &&
                (q.isEmpty() ||
                    e.title.lowercase().contains(q) ||
                    e.username.lowercase().contains(q) ||
                    e.website.lowercase().contains(q))
        }.sortedWith(compareByDescending<Entry> { it.favorite }.thenByDescending { it.updatedAt })
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Header
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("VaultX", color = VC.Text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "${all.size} items · encrypted on this phone",
                        color = VC.Muted,
                        fontSize = 13.sp
                    )
                }
                RoundIcon(Icons.Rounded.Settings, { vm.screen = Screen.Settings })
                Spacer(Modifier.width(8.dp))
                RoundIcon(Icons.Rounded.Lock, { vm.lock() }, tint = VC.Accent2)
            }

            // Search
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                placeholder = { Text("Search your vault") },
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = VC.Muted) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = vaultFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            )

            // Filter chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Chip("All", vm.filter == null) { vm.filter = null } }
                items(EntryType.values().toList()) { t ->
                    Chip(if (t == EntryType.NOTE) "Notes" else t.label, vm.filter == t) {
                        vm.filter = if (vm.filter == t) null else t
                    }
                }
            }

            if (list.isEmpty()) {
                EmptyState(hasAny = all.isNotEmpty())
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(list, key = { it.id }) { e ->
                        EntryCard(e) { vm.screen = Screen.Detail(e.id) }
                    }
                }
            }
        }

        // Add button
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .size(64.dp)
                .clip(CircleShape)
                .background(VC.accentBrush)
                .clickable {
                    vm.screen = Screen.Edit(null, vm.filter ?: EntryType.FACEBOOK)
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Add, "Add", tint = Color.White, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val brush: Brush = if (selected) VC.accentBrush else SolidColor(VC.Card)
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(brush)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(
            text,
            color = if (selected) Color.White else VC.Muted,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun EntryCard(e: Entry, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TypeBadge(e.type)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    e.title,
                    color = VC.Text,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val sub = if (e.type.isNote) e.notes.replace('\n', ' ') else e.username
                if (sub.isNotBlank()) {
                    Text(
                        sub,
                        color = VC.Muted,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (e.favorite) {
                Icon(Icons.Rounded.Star, null, tint = VC.Gold, modifier = Modifier.size(22.dp))
            }
        }
    }
}

@Composable
private fun EmptyState(hasAny: Boolean) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(VC.accentBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(22.dp))
        Text(
            if (hasAny) "Nothing found" else "Your vault is empty",
            color = VC.Text,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (hasAny) "Try a different search or filter."
            else "Tap + to save a Facebook, email or any other login, or write a private note.",
            color = VC.Muted,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
    }
}
