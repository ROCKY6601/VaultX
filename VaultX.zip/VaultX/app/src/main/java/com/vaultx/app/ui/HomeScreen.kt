package com.vaultx.app.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.Screen
import com.vaultx.app.VaultViewModel
import com.vaultx.app.data.Entry
import com.vaultx.app.data.EntryType

@Composable
fun HomeScreen(vm: VaultViewModel, onRequestStorage: () -> Unit) {
    val all = vm.entries
    val q = vm.query.trim().lowercase()
    val list = remember(all, q, vm.filter) {
        all.filter { e ->
            (vm.filter == null || e.type == vm.filter) &&
                (q.isEmpty() ||
                    e.title.lowercase().contains(q) ||
                    e.username.lowercase().contains(q) ||
                    e.website.lowercase().contains(q))
        }.sortedWith(compareByDescending<Entry> { it.favorite }.thenByDescending { it.updatedAt })
    }
    val logins = all.count { !it.type.isNote }
    val notes = all.count { it.type.isNote }
    val favs = all.count { it.favorite }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ---- Header ----
            Appear(0, Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("ROTH", color = VC.Text, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "Encrypted · only on this phone",
                            color = VC.Muted,
                            fontSize = 13.sp
                        )
                    }
                    RoundIcon(Icons.Rounded.Settings, { vm.screen = Screen.Settings })
                    Spacer(Modifier.width(8.dp))
                    RoundIcon(Icons.Rounded.Lock, { vm.lock() }, tint = VC.Accent2)
                }
            }

            // ---- Stats ----
            Appear(1, Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatTile("Logins", logins, VC.Accent2, Modifier.weight(1f))
                    StatTile("Notes", notes, VC.Gold, Modifier.weight(1f))
                    StatTile("Favourites", favs, VC.Pink, Modifier.weight(1f))
                }
            }

            // ---- Backup banner ----
            if (!vm.backupAccess) {
                Appear(2, Modifier.fillMaxWidth()) {
                    GlassCard(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 4.dp),
                        onClick = onRequestStorage
                    ) {
                        Text("Turn on safe backup", color = VC.Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Keeps an encrypted copy on this phone so your data survives uninstall. Tap to allow storage access.",
                            color = VC.Muted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // ---- Search ----
            Appear(2, Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.query = it },
                    placeholder = { Text("Search your vault") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null, tint = VC.Muted) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = vaultFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                )
            }

            // ---- Filter chips ----
            Appear(3, Modifier.fillMaxWidth()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Chip("All", vm.filter == null) { vm.filter = null } }
                    items(EntryType.values().toList()) { t ->
                        Chip(if (t == EntryType.NOTE) "Notes" else t.label, vm.filter == t) {
                            vm.filter = if (vm.filter == t) null else t
                        }
                    }
                }
            }

            if (list.isEmpty()) {
                EmptyState(hasAny = all.isNotEmpty())
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(list, key = { _, e -> e.id }) { i, e ->
                        Appear(minOf(i, 6), Modifier.fillMaxWidth()) {
                            EntryCard(e) { vm.screen = Screen.Detail(e.id) }
                        }
                    }
                }
            }
        }

        // ---- Add button with pulsing ring ----
        val t = rememberInfiniteTransition(label = "fab")
        val pulse by t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Restart),
            label = "pulse"
        )
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(64.dp)
                    .graphicsLayer {
                        scaleX = 1f + 0.6f * pulse
                        scaleY = 1f + 0.6f * pulse
                        alpha = 0.55f * (1f - pulse)
                    }
                    .clip(CircleShape)
                    .background(VC.Accent)
            )
            Box(
                Modifier
                    .bounceClick { vm.screen = Screen.Edit(null, vm.filter ?: EntryType.FACEBOOK) }
                    .size(64.dp)
                    .shadow(20.dp, CircleShape, ambientColor = VC.Accent, spotColor = VC.Accent2)
                    .clip(CircleShape)
                    .background(VC.accentBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Add, "Add", tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    val n by animateIntAsState(targetValue = value, animationSpec = tween(800), label = "stat")
    GlassCard(modifier) {
        Text(n.toString(), color = color, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = VC.Muted, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val brush: Brush = if (selected) VC.accentBrush else SolidColor(VC.Card)
    Box(
        Modifier
            .bounceClick(onClick = onClick)
            .clip(RoundedCornerShape(50))
            .background(brush)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(
            text,
            color = if (selected) Color.White else VC.Muted,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun EntryCard(e: Entry, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TypeBadge(e.type)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    e.title,
                    color = VC.Text,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val sub = if (e.type.isNote) e.notes.replace('\n', ' ') else e.username
                if (sub.isNotBlank()) {
                    Text(
                        sub,
                        color = VC.Muted,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (e.favorite) {
                Icon(Icons.Rounded.Star, null, tint = VC.Gold, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(4.dp))
            }
            Icon(Icons.Rounded.ChevronRight, null, tint = VC.Muted, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun EmptyState(hasAny: Boolean) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .floating(10f)
                .size(104.dp)
                .shadow(28.dp, CircleShape, ambientColor = VC.Accent, spotColor = VC.Accent2)
                .clip(CircleShape)
                .background(VC.accentBrush),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(52.dp))
        }
        Spacer(Modifier.height(26.dp))
        Text(
            if (hasAny) "Nothing found" else "Your vault is empty",
            color = VC.Text,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (hasAny) "Try a different search or filter."
            else "Tap + to save a Facebook, email or any other login, or write a private note.",
            color = VC.Muted,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
    }
}
