package com.vaultx.app.data

import org.json.JSONObject

enum class EntryType(
    val label: String,
    val glyph: String,
    val colorHex: Long,
    val userLabel: String,
    val isNote: Boolean = false
) {
    FACEBOOK("Facebook", "f", 0xFF1877F2, "Email or phone"),
    EMAIL("Email", "@", 0xFFEA4335, "Email address"),
    INSTAGRAM("Instagram", "IG", 0xFFE1306C, "Username or email"),
    GOOGLE("Google", "G", 0xFF34A853, "Gmail address"),
    OTHER("Other", "★", 0xFF7C5CFF, "Username or email"),
    NOTE("Note", "✎", 0xFFF59E0B, "", isNote = true)
}

data class Entry(
    val id: String,
    val type: EntryType,
    val title: String,
    val username: String,
    val password: String,
    val website: String,
    val notes: String,
    val favorite: Boolean,
    val updatedAt: Long
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("type", type.name)
        .put("title", title)
        .put("username", username)
        .put("password", password)
        .put("website", website)
        .put("notes", notes)
        .put("favorite", favorite)
        .put("updatedAt", updatedAt)

    companion object {
        fun fromJson(o: JSONObject): Entry = Entry(
            id = o.getString("id"),
            type = runCatching { EntryType.valueOf(o.getString("type")) }.getOrDefault(EntryType.OTHER),
            title = o.optString("title"),
            username = o.optString("username"),
            password = o.optString("password"),
            website = o.optString("website"),
            notes = o.optString("notes"),
            favorite = o.optBoolean("favorite"),
            updatedAt = o.optLong("updatedAt")
        )
    }
}
