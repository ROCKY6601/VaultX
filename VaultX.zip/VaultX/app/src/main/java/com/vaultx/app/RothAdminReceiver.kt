package com.vaultx.app

import android.app.admin.DeviceAdminReceiver

/** Lets the user mark ROTH as protected so it can't be uninstalled by accident. No other powers are used. */
class RothAdminReceiver : DeviceAdminReceiver()
