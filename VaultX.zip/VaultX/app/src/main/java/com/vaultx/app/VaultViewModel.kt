package com.vaultx.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.vaultx.app.data.Entry
import com.vaultx.app.data.EntryType
import com.vaultx.app.data.VaultRepository

sealed interface Screen {
    object Home : Screen
    data class Edit(val id: String?, val type: EntryType = EntryType.FACEBOOK) : Screen
    data class Detail(val id: String) : Screen
    object Settings : Screen
}

class VaultViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = VaultRepository(app)

    var unlocked by mutableStateOf(false); private set
    var hasPin by mutableStateOf(repo.hasPin()); private set
    var entries by mutableStateOf<List<Entry>>(emptyList()); private set
    var screen by mutableStateOf<Screen>(Screen.Home)
    var query by mutableStateOf("")
    var filter by mutableStateOf<EntryType?>(null)
    var biometricEnabled by mutableStateOf(repo.biometricEnabled); private set
    var autoLock by mutableStateOf(repo.autoLockSeconds); private set

    // ----- lock / unlock -----
    fun createPin(pin: String) {
        repo.setPin(pin)
        hasPin = true
        unlock()
    }

    /** 0 = ok, -1 = wrong, >0 = locked out for that many seconds. */
    fun attempt(pin: String): Int = repo.attempt(pin)

    fun unlock() {
        if (!repo.hasPin()) return
        entries = repo.load()
        screen = Screen.Home
        unlocked = true
    }

    fun lock() {
        unlocked = false
        entries = emptyList()
        screen = Screen.Home
        query = ""
        filter = null
    }

    fun changePin(old: String, new: String): Boolean {
        if (!repo.verify(old)) return false
        repo.setPin(new)
        return true
    }

    fun wipeAll() {
        repo.wipe()
        hasPin = false
        biometricEnabled = false
        autoLock = repo.autoLockSeconds
        lock()
    }

    // ----- settings -----
    fun setBiometric(v: Boolean) { biometricEnabled = v; repo.biometricEnabled = v }
    fun setAutoLock(s: Int) { autoLock = s; repo.autoLockSeconds = s }

    // ----- data -----
    fun upsert(e: Entry) {
        val list = entries.toMutableList()
        val i = list.indexOfFirst { it.id == e.id }
        if (i >= 0) list[i] = e else list.add(e)
        entries = list
        repo.save(list)
    }

    fun delete(id: String) {
        entries = entries.filterNot { it.id == id }
        repo.save(entries)
    }

    fun toggleFavorite(id: String) {
        val e = entries.firstOrNull { it.id == id } ?: return
        upsert(e.copy(favorite = !e.favorite))
    }

    // ----- navigation -----
    fun back() {
        screen = when (val s = screen) {
            is Screen.Edit -> if (s.id != null) Screen.Detail(s.id) else Screen.Home
            is Screen.Detail -> Screen.Home
            Screen.Settings -> Screen.Home
            Screen.Home -> Screen.Home
        }
    }
}
