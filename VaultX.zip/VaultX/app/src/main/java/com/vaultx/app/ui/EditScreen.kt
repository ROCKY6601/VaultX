package com.vaultx.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.Screen
import com.vaultx.app.VaultViewModel
import com.vaultx.app.data.Entry
import com.vaultx.app.data.EntryType
import java.security.SecureRandom
import java.util.UUID

private fun generatePassword(len: Int = 16): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#\$%&*?"
    val r = SecureRandom()
    return (1..len).map { chars[r.nextInt(chars.length)] }.joinToString("")
}

private fun strength(p: String): Int {
    if (p.isEmpty()) return 0
    var s = 0
    if (p.length >= 8) s++
    if (p.length >= 12) s++
    if (p.any { it.isUpperCase() } && p.any { it.isLowerCase() }) s++
    if (p.any { it.isDigit() }) s++
    if (p.any { !it.isLetterOrDigit() }) s++
    return minOf(s, 4)
}

@Composable
fun EditScreen(vm: VaultViewModel, id: String?, presetType: EntryType) {
    val existing = remember(id) { vm.entries.firstOrNull { it.id == id } }
    var type by remember { mutableStateOf(existing?.type ?: presetType) }
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var username by remember { mutableStateOf(existing?.username ?: "") }
    var password by remember { mutableStateOf(existing?.password ?: "") }
    var website by remember { mutableStateOf(existing?.website ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var showPass by remember { mutableStateOf(false) }

    val canSave = if (type.isNote) {
        notes.isNotBlank() || title.isNotBlank()
    } else {
        username.isNotBlank() || password.isNotBlank()
    }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        ScreenHeader(if (existing == null) "New item" else "Edit item", onBack = { vm.back() })

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Appear(0, Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionLabel("What do you want to save?")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(EntryType.values().toList()) { t ->
                            val selected = t == type
                            val bg by animateColorAsState(
                                targetValue = if (selected) VC.Accent else VC.Card,
                                label = "chipbg"
                            )
                            Row(
                                Modifier
                                    .bounceClick { type = t }
                                    .clip(RoundedCornerShape(50))
                                    .background(bg)
                                    .padding(start = 6.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TypeBadge(t, 30.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    t.label,
                                    color = if (selected) Color.White else VC.Muted,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            Appear(1, Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title (optional)") },
                    placeholder = { Text(if (type.isNote) "Note title" else type.label) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = vaultFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (!type.isNote) {
                Appear(2, Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text(type.userLabel) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        shape = RoundedCornerShape(16.dp),
                        colors = vaultFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Appear(3, Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            Icon(
                                if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                null,
                                tint = VC.Muted,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable { showPass = !showPass }
                                    .padding(6.dp)
                            )
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = vaultFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Strength + generator
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val s = strength(password)
                    val barColor = when (s) {
                        0, 1 -> VC.Danger
                        2 -> VC.Gold
                        else -> VC.Success
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        repeat(4) { i ->
                            val on by animateFloatAsState(if (i < s) 1f else 0f, label = "bar")
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(VC.CardHi)
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(on)
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(barColor)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        "Generate",
                        color = VC.Accent2,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .bounceClick {
                                password = generatePassword()
                                showPass = true
                            }
                            .clip(RoundedCornerShape(50))
                            .background(VC.Card)
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }

                OutlinedTextField(
                    value = website,
                    onValueChange = { website = it },
                    label = { Text("Website (optional)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    shape = RoundedCornerShape(16.dp),
                    colors = vaultFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(if (type.isNote) "Your note" else "Extra details (optional)") },
                shape = RoundedCornerShape(16.dp),
                colors = vaultFieldColors(),
                minLines = if (type.isNote) 8 else 3,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }

        GradientButton(
            text = "Save to vault",
            enabled = canSave,
            onClick = {
                val e = Entry(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    type = type,
                    title = title.trim().ifEmpty { type.label },
                    username = if (type.isNote) "" else username.trim(),
                    password = if (type.isNote) "" else password,
                    website = if (type.isNote) "" else website.trim(),
                    notes = notes.trim(),
                    favorite = existing?.favorite ?: false,
                    updatedAt = System.currentTimeMillis()
                )
                vm.upsert(e)
                vm.screen = Screen.Detail(e.id)
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        )
    }
}
