package com.vaultx.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.Screen
import com.vaultx.app.VaultViewModel
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.delay

@Composable
fun DetailScreen(vm: VaultViewModel, id: String) {
    val e = vm.entries.firstOrNull { it.id == id }
    if (e == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.Home }
        Box(Modifier.fillMaxSize())
        return
    }
    val ctx = LocalContext.current
    var showPass by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = e.title,
            onBack = { vm.back() },
            actions = {
                RoundIcon(
                    if (e.favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    { vm.toggleFavorite(e.id) },
                    tint = if (e.favorite) VC.Gold else VC.Text
                )
                RoundIcon(Icons.Rounded.Edit, { vm.screen = Screen.Edit(e.id, e.type) })
                RoundIcon(Icons.Rounded.Delete, { confirmDelete = true }, tint = VC.Danger)
            }
        )

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Appear(0, Modifier.fillMaxWidth()) {
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TypeBadge(e.type, 60.dp)
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(
                                if (e.type.isNote) "Private note" else e.type.label + " account",
                                color = VC.Text,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Updated " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                                    .format(Date(e.updatedAt)),
                                color = VC.Muted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            var idx = 1
            if (!e.type.isNote) {
                if (e.username.isNotEmpty()) {
                    Appear(idx++, Modifier.fillMaxWidth()) {
                        FieldCard(
                            label = e.type.userLabel,
                            value = e.username,
                            onCopy = { copyToClipboard(ctx, "Username", e.username) }
                        )
                    }
                }
                if (e.password.isNotEmpty()) {
                    Appear(idx++, Modifier.fillMaxWidth()) {
                        FieldCard(
                            label = "Password",
                            value = if (showPass) e.password else "•".repeat(minOf(e.password.length, 14)),
                            onCopy = { copyToClipboard(ctx, "Password", e.password) },
                            trailing = {
                                Icon(
                                    if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    null,
                                    tint = VC.Muted,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .clickable { showPass = !showPass }
                                        .padding(8.dp)
                                        .size(22.dp)
                                )
                            }
                        )
                    }
                }
                if (e.website.isNotEmpty()) {
                    Appear(idx++, Modifier.fillMaxWidth()) {
                        FieldCard(
                            label = "Website",
                            value = e.website,
                            onCopy = { copyToClipboard(ctx, "Website", e.website) }
                        )
                    }
                }
            }

            if (e.notes.isNotEmpty()) {
                Appear(idx++, Modifier.fillMaxWidth()) {
                    FieldCard(
                        label = if (e.type.isNote) "Note" else "Details",
                        value = e.notes,
                        onCopy = { copyToClipboard(ctx, "Text", e.notes) }
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = VC.Surface,
            title = { Text("Delete this item?", color = VC.Text) },
            text = { Text("It will be permanently removed from your vault.", color = VC.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.screen = Screen.Home
                    vm.delete(e.id)
                }) { Text("Delete", color = VC.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = VC.Muted) }
            }
        )
    }
}

@Composable
private fun FieldCard(
    label: String,
    value: String,
    onCopy: () -> Unit,
    trailing: @Composable (() -> Unit)? = null
) {
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }
    GlassCard(Modifier.fillMaxWidth()) {
        SectionLabel(label)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedContent(
                targetState = value,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) },
                modifier = Modifier.weight(1f),
                label = "value"
            ) { v ->
                Text(v, color = VC.Text, fontSize = 17.sp)
            }
            trailing?.invoke()
            Icon(
                if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                "Copy",
                tint = if (copied) VC.Success else VC.Accent2,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable {
                        onCopy()
                        copied = true
                    }
                    .padding(8.dp)
                    .size(22.dp)
            )
        }
    }
}
