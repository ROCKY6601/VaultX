package com.vaultx.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object VC {
    val Bg = Color(0xFF07070F)
    val Bg2 = Color(0xFF110E2B)
    val Surface = Color(0xFF1B1A36)
    val Card = Color(0x1AFFFFFF)
    val CardHi = Color(0x2EFFFFFF)
    val Accent = Color(0xFF7C5CFF)
    val Accent2 = Color(0xFF22D3EE)
    val Pink = Color(0xFFFF4DA6)
    val Text = Color(0xFFF4F4FF)
    val Muted = Color(0xFFA4A6CE)
    val Danger = Color(0xFFFF5C7A)
    val Gold = Color(0xFFFFC145)
    val Success = Color(0xFF34D399)
    val Border = Color(0x2BFFFFFF)

    val accentBrush: Brush = Brush.linearGradient(listOf(Accent, Accent2))
    val bgBrush: Brush = Brush.verticalGradient(listOf(Bg2, Bg))
}

/** Slowly moving coloured glow behind the whole app. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "p"
    )
    Canvas(modifier.fillMaxSize()) {
        drawRect(VC.bgBrush)
        val w = size.width
        val h = size.height
        drawRect(
            Brush.radialGradient(
                colors = listOf(VC.Accent.copy(alpha = 0.40f), Color.Transparent),
                center = Offset(w * (0.1f + 0.6f * p), h * (0.08f + 0.12f * p)),
                radius = w * 0.95f
            )
        )
        drawRect(
            Brush.radialGradient(
                colors = listOf(VC.Accent2.copy(alpha = 0.28f), Color.Transparent),
                center = Offset(w * (0.95f - 0.6f * p), h * (0.88f - 0.15f * p)),
                radius = w * 0.9f
            )
        )
        drawRect(
            Brush.radialGradient(
                colors = listOf(VC.Pink.copy(alpha = 0.16f), Color.Transparent),
                center = Offset(w * 0.5f, h * (0.45f + 0.1f * p)),
                radius = w * 0.7f
            )
        )
    }
}

@Composable
fun VaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = VC.Accent,
            onPrimary = Color.White,
            background = VC.Bg,
            onBackground = VC.Text,
            surface = VC.Surface,
            onSurface = VC.Text,
            error = VC.Danger
        ),
        content = content
    )
}
