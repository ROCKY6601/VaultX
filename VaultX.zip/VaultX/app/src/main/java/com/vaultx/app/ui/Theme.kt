package com.vaultx.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object VC {
    val Bg = Color(0xFF0A0A14)
    val Bg2 = Color(0xFF14112E)
    val Card = Color(0xFF181830)
    val CardHi = Color(0xFF242446)
    val Accent = Color(0xFF7C5CFF)
    val Accent2 = Color(0xFF22D3EE)
    val Text = Color(0xFFF4F4FF)
    val Muted = Color(0xFF9A9CC4)
    val Danger = Color(0xFFFF5C7A)
    val Gold = Color(0xFFFFC145)
    val Border = Color(0x24FFFFFF)

    val accentBrush: Brush = Brush.linearGradient(listOf(Accent, Accent2))
    val bgBrush: Brush = Brush.verticalGradient(listOf(Bg2, Bg))
}

@Composable
fun VaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = VC.Accent,
            onPrimary = Color.White,
            background = VC.Bg,
            onBackground = VC.Text,
            surface = VC.Card,
            onSurface = VC.Text,
            error = VC.Danger
        ),
        content = content
    )
}
