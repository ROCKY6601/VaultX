package com.vaultx.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast
import com.vaultx.app.VaultViewModel
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val PIN_LEN = 6

/** Create-PIN flow on first launch, PIN pad (+ fingerprint) afterwards. */
@Composable
fun LockScreen(vm: VaultViewModel, onBiometric: () -> Unit, onRequestStorage: () -> Unit) {
    val setup = !vm.hasPin
    val ctx = LocalContext.current
    var restoreMode by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var lockLeft by remember { mutableIntStateOf(0) }
    val shake = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        if (!setup && vm.biometricEnabled) onBiometric()
    }
    LaunchedEffect(vm.backupExists, setup) {
        if (setup && vm.backupExists) restoreMode = true
    }
    LaunchedEffect(lockLeft) {
        if (lockLeft > 0) {
            delay(1000)
            lockLeft -= 1
            if (lockLeft == 0) error = null
        }
    }

    fun doShake() {
        scope.launch {
            repeat(3) {
                shake.animateTo(16f, tween(60))
                shake.animateTo(-16f, tween(60))
            }
            shake.animateTo(0f, tween(60))
        }
    }

    fun submit(p: String) {
        if (setup && restoreMode) {
            pin = ""
            if (!vm.restore(p)) {
                error = "Wrong PIN or damaged backup"
                doShake()
            }
            return
        }
        if (setup) {
            val f = first
            if (f == null) {
                first = p
                pin = ""
                error = null
            } else if (f == p) {
                vm.createPin(p)
            } else {
                error = "PINs did not match. Try again."
                first = null
                pin = ""
                doShake()
            }
        } else {
            val r = vm.attempt(p)
            pin = ""
            when {
                r == 0 -> vm.unlock()
                r < 0 -> {
                    error = "Wrong PIN"
                    doShake()
                }
                else -> {
                    lockLeft = r
                    error = "Too many attempts"
                    doShake()
                }
            }
        }
    }

    fun press(d: String) {
        if (lockLeft > 0 || pin.length >= PIN_LEN) return
        pin += d
        if (pin.length == PIN_LEN) submit(pin)
    }

    val title = when {
        setup && restoreMode -> "Restore your vault"
        !setup -> "Welcome back"
        first == null -> "Create your PIN"
        else -> "Confirm your PIN"
    }
    val subtitle = when {
        setup && restoreMode -> "Backup found. Enter the PIN you used before."
        !setup -> "Enter your PIN to unlock"
        first == null -> "Choose a 6-digit PIN. Only you will know it."
        else -> "Enter the same PIN once more"
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .floating(8f)
                    .size(86.dp)
                    .shadow(24.dp, CircleShape, ambientColor = VC.Accent, spotColor = VC.Accent2)
                    .clip(CircleShape)
                    .background(VC.accentBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "ROTH",
                color = VC.Accent2,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(title, color = VC.Text, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                subtitle,
                color = VC.Muted,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                textAlign = TextAlign.Center
            )
            if (setup) {
                Spacer(Modifier.height(10.dp))
                Text(
                    if (restoreMode) "Start fresh instead" else "Reinstalled? Restore from backup",
                    color = VC.Accent2,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .clickable {
                            pin = ""
                            error = null
                            if (restoreMode) {
                                restoreMode = false
                            } else if (!vm.backupAccess) {
                                onRequestStorage()
                            } else if (vm.backupExists) {
                                restoreMode = true
                            } else {
                                Toast.makeText(ctx, "No backup found on this phone", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                Modifier.offset { IntOffset(shake.value.roundToInt(), 0) },
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(PIN_LEN) { i ->
                    val filled = i < pin.length
                    val sz by animateDpAsState(
                        targetValue = if (filled) 20.dp else 14.dp,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "dot"
                    )
                    val brush: Brush = if (filled) VC.accentBrush else SolidColor(VC.CardHi)
                    Box(
                        Modifier
                            .size(sz)
                            .clip(CircleShape)
                            .background(brush)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            val msg = if (lockLeft > 0) "Try again in ${lockLeft}s" else (error ?: "")
            Text(
                msg,
                color = VC.Danger,
                fontSize = 13.sp,
                modifier = Modifier.height(18.dp)
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    row.forEach { d -> PadKey(d) { press(d) } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                if (!setup && vm.biometricEnabled) {
                    Box(
                        Modifier
                            .bounceClick(onClick = onBiometric)
                            .size(74.dp)
                            .clip(CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Fingerprint, null, tint = VC.Accent2, modifier = Modifier.size(36.dp))
                    }
                } else {
                    Spacer(Modifier.size(74.dp))
                }
                PadKey("0") { press("0") }
                PadKey("⌫") {
                    if (pin.isNotEmpty()) pin = pin.dropLast(1)
                }
            }
        }
    }
}

@Composable
private fun PadKey(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .bounceClick(onClick = onClick)
            .size(74.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0x2EFFFFFF), Color(0x12FFFFFF))))
            .border(1.dp, VC.Border, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = VC.Text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
    }
}
