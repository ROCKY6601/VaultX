package com.vaultx.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.VaultViewModel
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

private const val PIN_LEN = 6

/**
 * First launch: asks the user to create a PIN.
 * Afterwards the app looks and works like a normal calculator. Typing the PIN and pressing "="
 * opens the vault.
 */
@Composable
fun LockScreen(vm: VaultViewModel, onBiometric: () -> Unit) {
    if (!vm.hasPin) SetupScreen(vm) else CalculatorScreen(vm, onBiometric)
}

// =====================================================================================
// First-time PIN setup
// =====================================================================================

@Composable
private fun SetupScreen(vm: VaultViewModel) {
    var pin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val shake = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    fun submit(p: String) {
        val f = first
        if (f == null) {
            first = p
            pin = ""
            error = null
        } else if (f == p) {
            vm.createPin(p)
        } else {
            error = "PINs did not match. Try again."
            first = null
            pin = ""
            scope.launch {
                repeat(3) {
                    shake.animateTo(16f, tween(60))
                    shake.animateTo(-16f, tween(60))
                }
                shake.animateTo(0f, tween(60))
            }
        }
    }

    fun press(d: String) {
        if (pin.length >= PIN_LEN) return
        pin += d
        if (pin.length == PIN_LEN) submit(pin)
    }

    val title = if (first == null) "Create your PIN" else "Confirm your PIN"
    val subtitle = if (first == null) {
        "Choose a 6-digit PIN.\nTo open your vault later: open this app, type the PIN and press ="
    } else {
        "Enter the same PIN once more"
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .floating(8f)
                    .size(86.dp)
                    .shadow(24.dp, CircleShape, ambientColor = VC.Accent, spotColor = VC.Accent2)
                    .clip(CircleShape)
                    .background(VC.accentBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Shield, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text(title, color = VC.Text, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                subtitle,
                color = VC.Muted,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                textAlign = TextAlign.Center
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                Modifier.offset { IntOffset(shake.value.roundToInt(), 0) },
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(PIN_LEN) { i ->
                    val filled = i < pin.length
                    val sz by animateDpAsState(
                        targetValue = if (filled) 20.dp else 14.dp,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        label = "dot"
                    )
                    val brush: Brush = if (filled) VC.accentBrush else SolidColor(VC.CardHi)
                    Box(
                        Modifier
                            .size(sz)
                            .clip(CircleShape)
                            .background(brush)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                error ?: "",
                color = VC.Danger,
                fontSize = 13.sp,
                modifier = Modifier.height(18.dp)
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    row.forEach { d -> PadKey(d) { press(d) } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                Spacer(Modifier.size(74.dp))
                PadKey("0") { press("0") }
                PadKey("⌫") {
                    if (pin.isNotEmpty()) pin = pin.dropLast(1)
                }
            }
        }
    }
}

@Composable
private fun PadKey(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .bounceClick(onClick = onClick)
            .size(74.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0x2EFFFFFF), Color(0x12FFFFFF))))
            .border(1.dp, VC.Border, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = VC.Text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
    }
}

// =====================================================================================
// Calculator disguise
// =====================================================================================

private fun fmt(v: Double): String {
    if (v.isNaN() || v.isInfinite()) return "Error"
    val s = BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    return if (s.length > 13) String.format(Locale.US, "%.6e", v) else s
}

private fun calc(a: Double, b: Double, op: String): Double = when (op) {
    "+" -> a + b
    "−" -> a - b
    "×" -> a * b
    else -> if (b == 0.0) Double.NaN else a / b
}

@Composable
private fun CalculatorScreen(vm: VaultViewModel, onBiometric: () -> Unit) {
    var display by remember { mutableStateOf("0") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf<String?>(null) }
    var fresh by remember { mutableStateOf(true) }

    fun clearAll() {
        display = "0"
        acc = null
        op = null
        fresh = true
    }

    fun digit(d: String) {
        if (fresh) {
            display = d
            fresh = false
        } else if (display.length < 12) {
            display = if (display == "0") d else display + d
        }
    }

    fun dot() {
        if (fresh) {
            display = "0."
            fresh = false
        } else if (!display.contains('.')) {
            display += "."
        }
    }

    fun pressOp(o: String) {
        val cur = display.toDoubleOrNull() ?: 0.0
        val a = acc
        val p = op
        if (a != null && p != null && !fresh) {
            val r = calc(a, cur, p)
            if (r.isNaN() || r.isInfinite()) {
                display = "Error"
                acc = null
                op = null
                fresh = true
                return
            }
            acc = r
            display = fmt(r)
        } else {
            acc = cur
        }
        op = o
        fresh = true
    }

    fun equalsPress() {
        // Secret: a typed 6-digit number followed by "=" is treated as the PIN.
        if (op == null && acc == null && !fresh && display.length == PIN_LEN && display.all { it.isDigit() }) {
            val r = vm.attempt(display)
            if (r == 0) {
                clearAll()
                vm.unlock()
                return
            }
            // wrong PIN (or temporary lock): behave exactly like a normal calculator
        }
        val a = acc
        val p = op
        if (a != null && p != null) {
            val cur = display.toDoubleOrNull() ?: 0.0
            display = fmt(calc(a, cur, p))
            acc = null
            op = null
            fresh = true
        } else {
            fresh = true
        }
    }

    fun negate() {
        if (display == "0" || display == "Error") return
        display = if (display.startsWith("-")) display.drop(1) else "-$display"
    }

    fun percent() {
        val cur = display.toDoubleOrNull() ?: return
        display = fmt(cur / 100.0)
        fresh = true
    }

    fun backspace() {
        if (fresh || display == "Error") {
            display = "0"
            fresh = true
            return
        }
        val n = display.dropLast(1)
        display = if (n.isEmpty() || n == "-") "0" else n
    }

    fun onKey(k: String) {
        when (k) {
            "AC" -> clearAll()
            "±" -> negate()
            "%" -> percent()
            "÷", "×", "−", "+" -> pressOp(k)
            "." -> dot()
            "=" -> equalsPress()
            else -> digit(k)
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        val gap = 12.dp
        val key = (maxWidth - gap * 3) / 4

        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Bottom) {
            // ---- display ----
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clickable { backspace() }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Bottom
            ) {
                val a = acc
                val p = op
                Text(
                    if (a != null && p != null) fmt(a) + " " + p else "",
                    color = VC.Muted,
                    fontSize = 20.sp,
                    maxLines = 1
                )
                Spacer(Modifier.height(6.dp))
                val size = when {
                    display.length > 10 -> 44.sp
                    display.length > 7 -> 58.sp
                    else -> 80.sp
                }
                Text(
                    display,
                    color = Color.White,
                    fontSize = size,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    textAlign = TextAlign.End
                )
            }
            Spacer(Modifier.height(10.dp))

            val rows = listOf(
                listOf("AC", "±", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+")
            )
            Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        row.forEach { k ->
                            val kind = when (k) {
                                "AC", "±", "%" -> 1
                                "÷", "×", "−", "+" -> 2
                                else -> 0
                            }
                            CalcKey(
                                label = k,
                                width = key,
                                height = key,
                                kind = kind,
                                active = kind == 2 && op == k && fresh
                            ) { onKey(k) }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    CalcKey(label = "0", width = key * 2 + gap, height = key, kind = 0) { onKey("0") }
                    CalcKey(label = ".", width = key, height = key, kind = 0) { onKey(".") }
                    CalcKey(
                        label = "=",
                        width = key,
                        height = key,
                        kind = 3,
                        onLong = if (vm.biometricEnabled) onBiometric else null
                    ) { onKey("=") }
                }
            }
        }
    }
}

@Composable
private fun CalcKey(
    label: String,
    width: Dp,
    height: Dp,
    kind: Int,
    active: Boolean = false,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val brush: Brush = when {
        active -> SolidColor(Color.White)
        kind == 2 -> VC.accentBrush
        kind == 3 -> Brush.linearGradient(listOf(VC.Accent2, VC.Accent))
        kind == 1 -> Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x2AFFFFFF)))
        else -> Brush.verticalGradient(listOf(Color(0x26FFFFFF), Color(0x10FFFFFF)))
    }
    Box(
        Modifier
            .bounceClick(onLongClick = onLong, onClick = onClick)
            .width(width)
            .height(height)
            .clip(RoundedCornerShape(50))
            .background(brush)
            .border(1.dp, VC.Border, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (active) VC.Accent else Color.White,
            fontSize = if (kind == 2 || kind == 3) 32.sp else 28.sp,
            fontWeight = if (kind == 1) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}
