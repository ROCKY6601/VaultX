package com.vaultx.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.VaultViewModel
import kotlinx.coroutines.delay

private const val PIN_LEN = 6

@Composable
fun LockScreen(vm: VaultViewModel, onBiometric: () -> Unit) {
    val setup = !vm.hasPin
    var pin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var lockLeft by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        if (!setup && vm.biometricEnabled) onBiometric()
    }
    LaunchedEffect(lockLeft) {
        if (lockLeft > 0) {
            delay(1000)
            lockLeft -= 1
            if (lockLeft == 0) error = null
        }
    }

    fun submit(p: String) {
        if (setup) {
            val f = first
            if (f == null) {
                first = p
                pin = ""
                error = null
            } else if (f == p) {
                vm.createPin(p)
            } else {
                error = "PINs did not match. Try again."
                first = null
                pin = ""
            }
        } else {
            val r = vm.attempt(p)
            pin = ""
            when {
                r == 0 -> vm.unlock()
                r < 0 -> error = "Wrong PIN"
                else -> {
                    lockLeft = r
                    error = "Too many attempts"
                }
            }
        }
    }

    fun press(d: String) {
        if (lockLeft > 0 || pin.length >= PIN_LEN) return
        pin += d
        if (pin.length == PIN_LEN) submit(pin)
    }

    val title = when {
        !setup -> "Welcome back"
        first == null -> "Create your PIN"
        else -> "Confirm your PIN"
    }
    val subtitle = when {
        !setup -> "Enter your PIN to unlock your vault"
        first == null -> "Choose a 6-digit PIN. Only you will know it."
        else -> "Enter the same PIN once more"
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(VC.accentBrush),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, null, tint = Color.White, modifier = Modifier.size(38.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text(title, color = VC.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = VC.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(PIN_LEN) { i ->
                    val filled = i < pin.length
                    val brush: Brush = if (filled) VC.accentBrush else SolidColor(VC.CardHi)
                    Box(
                        Modifier
                            .size(15.dp)
                            .clip(CircleShape)
                            .background(brush)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            val msg = when {
                lockLeft > 0 -> "Try again in ${lockLeft}s"
                else -> error ?: ""
            }
            Text(
                msg,
                color = VC.Danger,
                fontSize = 13.sp,
                modifier = Modifier.height(18.dp)
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    row.forEach { d -> Key(d) { press(d) } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                if (!setup && vm.biometricEnabled) {
                    Box(
                        Modifier
                            .size(74.dp)
                            .clip(CircleShape)
                            .clickable { onBiometric() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Fingerprint, null, tint = VC.Accent2, modifier = Modifier.size(34.dp))
                    }
                } else {
                    Spacer(Modifier.size(74.dp))
                }
                Key("0") { press("0") }
                Box(
                    Modifier
                        .size(74.dp)
                        .clip(CircleShape)
                        .clickable {
                            if (pin.isNotEmpty()) pin = pin.dropLast(1)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text("⌫", color = VC.Text, fontSize = 26.sp)
                }
            }
        }
    }
}

@Composable
private fun Key(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(74.dp)
            .clip(CircleShape)
            .background(VC.Card)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = VC.Text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
    }
}
