package com.vaultx.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.vaultx.app.ui.AuroraBackground
import com.vaultx.app.ui.DetailScreen
import com.vaultx.app.ui.EditScreen
import com.vaultx.app.ui.HomeScreen
import com.vaultx.app.ui.LockScreen
import com.vaultx.app.ui.SettingsScreen
import com.vaultx.app.ui.VaultTheme

class MainActivity : FragmentActivity() {
    private val vm: VaultViewModel by viewModels()
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots and hides the app preview in the recents screen.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        setContent {
            VaultTheme {
                AppRoot(
                    vm = vm,
                    biometricAvailable = biometricAvailable(),
                    onBiometric = { promptBiometric() },
                    onRequestStorage = { requestStorage() },
                    isAdmin = { isAdmin() },
                    onToggleAdmin = { toggleAdmin(it) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshBackup()
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
        if (vm.unlocked && vm.autoLock == 0) vm.lock()
    }

    override fun onStart() {
        super.onStart()
        if (vm.unlocked && stoppedAt > 0L) {
            val away = SystemClock.elapsedRealtime() - stoppedAt
            if (away >= vm.autoLock * 1000L) vm.lock()
        }
        stoppedAt = 0L
    }

    // ----- encrypted backup: storage access -----
    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            val pkg = Uri.parse("package:$packageName")
            val ok = runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg))
            }.isSuccess
            if (!ok) {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                77
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        vm.refreshBackup()
    }

    // ----- protect from uninstall (device admin, user can turn it off any time) -----
    private fun adminComponent() = ComponentName(this, RothAdminReceiver::class.java)

    private fun dpm() = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private fun isAdmin(): Boolean = dpm().isAdminActive(adminComponent())

    private fun toggleAdmin(on: Boolean) {
        if (on) {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                .putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Stops ROTH from being uninstalled by accident. You can turn this off any time inside ROTH."
                )
            runCatching { startActivity(i) }
        } else {
            runCatching { dpm().removeActiveAdmin(adminComponent()) }
            vm.bump()
        }
    }

    private fun biometricAvailable(): Boolean =
        BiometricManager.from(this).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    private fun promptBiometric() {
        if (!vm.hasPin || !vm.biometricEnabled || !biometricAvailable()) return
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    vm.unlock()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ROTH")
            .setSubtitle("Use your fingerprint or face")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(info)
    }
}

private fun Screen.depth(): Int = when (this) {
    Screen.Home -> 0
    Screen.Settings -> 1
    is Screen.Detail -> 1
    is Screen.Edit -> 2
}

@Composable
fun AppRoot(
    vm: VaultViewModel,
    biometricAvailable: Boolean,
    onBiometric: () -> Unit,
    onRequestStorage: () -> Unit,
    isAdmin: () -> Boolean,
    onToggleAdmin: (Boolean) -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        Box(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            Crossfade(targetState = vm.unlocked, animationSpec = tween(400), label = "lock") { unlocked ->
                if (!unlocked) {
                    LockScreen(vm, onBiometric, onRequestStorage)
                } else {
                    BackHandler(enabled = vm.screen !is Screen.Home) { vm.back() }
                    AnimatedContent(
                        targetState = vm.screen,
                        transitionSpec = {
                            val forward = targetState.depth() >= initialState.depth()
                            (fadeIn(tween(320)) +
                                slideInHorizontally(tween(360)) { if (forward) it / 5 else -it / 5 }) togetherWith
                                (fadeOut(tween(200)) +
                                    slideOutHorizontally(tween(300)) { if (forward) -it / 8 else it / 8 })
                        },
                        label = "nav"
                    ) { s ->
                        when (s) {
                            Screen.Home -> HomeScreen(vm, onRequestStorage)
                            is Screen.Edit -> EditScreen(vm, s.id, s.type)
                            is Screen.Detail -> DetailScreen(vm, s.id)
                            Screen.Settings -> SettingsScreen(vm, biometricAvailable, onRequestStorage, isAdmin, onToggleAdmin)
                        }
                    }
                }
            }
        }
    }
}
