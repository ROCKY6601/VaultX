package com.vaultx.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Where the encrypted backup lives. It is OUTSIDE the app's private folder, so it is not
 * deleted when the app is uninstalled.  Folder is hidden (starts with a dot).
 */
object BackupStore {
    private const val DIR = ".ROTH"

    fun dir(): File = File(Environment.getExternalStorageDirectory(), DIR)
    fun file(): File = File(dir(), "roth.dat")

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
}

/** PIN-derived key (PBKDF2) wraps a random data key; AES-256-GCM everywhere. */
object BackupCrypto {
    val MAGIC: ByteArray = "ROTH1".toByteArray(Charsets.US_ASCII)
    const val ITERATIONS = 200_000
    const val SALT_LEN = 16
    const val IV_LEN = 12
    const val DEK_LEN = 32
    /** iv + dek + tag */
    const val WRAPPED_LEN = IV_LEN + DEK_LEN + 16
    /** salt + iterations(4) + wrapped key */
    const val HEADER_LEN = SALT_LEN + 4 + WRAPPED_LEN

    private val rnd = SecureRandom()

    fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    fun kek(pin: String, salt: ByteArray, iterations: Int): SecretKey {
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    fun encrypt(key: SecretKey, plain: ByteArray): ByteArray {
        val iv = random(IV_LEN)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }

    fun decrypt(key: SecretKey, data: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, IV_LEN)))
        return c.doFinal(data, IV_LEN, data.size - IV_LEN)
    }

    fun intToBytes(v: Int): ByteArray =
        byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())

    fun bytesToInt(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 24) or
            ((b[off + 1].toInt() and 0xFF) shl 16) or
            ((b[off + 2].toInt() and 0xFF) shl 8) or
            (b[off + 3].toInt() and 0xFF)
}
