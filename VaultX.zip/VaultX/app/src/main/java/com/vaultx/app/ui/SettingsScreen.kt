package com.vaultx.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vaultx.app.VaultViewModel

@Composable
fun SettingsScreen(vm: VaultViewModel, biometricAvailable: Boolean) {
    val ctx = LocalContext.current
    var showChangePin by remember { mutableStateOf(false) }
    var showWipe by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", onBack = { vm.back() })

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionLabel("Security")

            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Fingerprint / face unlock", color = VC.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (biometricAvailable) "Unlock faster. Your PIN still works."
                            else "Not set up on this phone.",
                            color = VC.Muted,
                            fontSize = 13.sp
                        )
                    }
                    Switch(
                        checked = vm.biometricEnabled && biometricAvailable,
                        onCheckedChange = { vm.setBiometric(it) },
                        enabled = biometricAvailable,
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = VC.Accent,
                            checkedThumbColor = androidx.compose.ui.graphics.Color.White
                        )
                    )
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("Auto-lock", color = VC.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Lock the vault after leaving the app", color = VC.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Instantly", 30 to "30 sec", 60 to "1 min", 300 to "5 min").forEach { (secs, label) ->
                        val sel = vm.autoLock == secs
                        Text(
                            label,
                            color = if (sel) androidx.compose.ui.graphics.Color.White else VC.Muted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (sel) VC.Accent else VC.CardHi)
                                .clickable { vm.changeAutoLock(secs) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            GlassCard(Modifier.fillMaxWidth(), onClick = { showChangePin = true }) {
                Text("Change PIN", color = VC.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Set a new 6-digit PIN", color = VC.Muted, fontSize = 13.sp)
            }

            SectionLabel("How to open your vault", Modifier.padding(top = 8.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    "This app looks like a normal Calculator. To open your vault: type your 6-digit PIN and press =.\n\n" +
                        "If you turned on fingerprint unlock, press and hold = instead.",
                    color = VC.Muted,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }

            SectionLabel("About your data", Modifier.padding(top = 8.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    "Everything is stored only on this phone, encrypted with AES-256 using a key kept in the Android Keystore. " +
                        "Nothing is sent to the internet. Screenshots are blocked, and copied passwords are cleared from the clipboard after 30 seconds.\n\n" +
                        "If you forget your PIN, the data cannot be recovered. Uninstalling the app also deletes the vault.",
                    color = VC.Muted,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }

            SectionLabel("Danger zone", Modifier.padding(top = 8.dp))
            GlassCard(Modifier.fillMaxWidth(), onClick = { showWipe = true }) {
                Text("Erase everything", color = VC.Danger, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Deletes all items and removes your PIN", color = VC.Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showChangePin) {
        ChangePinDialog(
            onDismiss = { showChangePin = false },
            onSubmit = { old, new ->
                val ok = vm.changePin(old, new)
                Toast.makeText(ctx, if (ok) "PIN changed" else "Current PIN is wrong", Toast.LENGTH_SHORT).show()
                if (ok) showChangePin = false
            }
        )
    }

    if (showWipe) {
        AlertDialog(
            onDismissRequest = { showWipe = false },
            containerColor = VC.Surface,
            title = { Text("Erase everything?", color = VC.Text) },
            text = { Text("All saved logins and notes will be deleted forever. This cannot be undone.", color = VC.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    showWipe = false
                    vm.wipeAll()
                }) { Text("Erase", color = VC.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { showWipe = false }) { Text("Cancel", color = VC.Muted) }
            }
        )
    }
}

@Composable
private fun ChangePinDialog(onDismiss: () -> Unit, onSubmit: (String, String) -> Unit) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    val valid = old.length == 6 && new.length == 6

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VC.Surface,
        title = { Text("Change PIN", color = VC.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = old,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) old = it },
                    label = { Text("Current PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = vaultFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = new,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) new = it },
                    label = { Text("New 6-digit PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = vaultFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSubmit(old, new) }, enabled = valid) {
                Text("Save", color = if (valid) VC.Accent2 else VC.Muted)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = VC.Muted) }
        }
    )
}
