package com.vaultx.app.data

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class VaultRepository(context: Context) {
    private val appCtx = context.applicationContext
    private val file = File(appCtx.filesDir, "vault.bin")
    private val prefs = appCtx.getSharedPreferences("vaultx_prefs", Context.MODE_PRIVATE)

    // ---------- PIN ----------
    fun hasPin(): Boolean = prefs.contains("pin_hash")

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("pin_salt", b64(salt))
            .putString("pin_hash", b64(hash(pin, salt)))
            .putInt("fails", 0)
            .putLong("lock_until", 0L)
            .apply()
    }

    fun verify(pin: String): Boolean {
        val salt = prefs.getString("pin_salt", null) ?: return false
        val stored = prefs.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(hash(pin, unb64(salt)), unb64(stored))
    }

    /** 0 = correct, -1 = wrong, >0 = locked out, value is seconds remaining. */
    fun attempt(pin: String): Int {
        val now = System.currentTimeMillis()
        val until = prefs.getLong("lock_until", 0L)
        if (until > now) return ((until - now + 999) / 1000).toInt()
        if (verify(pin)) {
            prefs.edit().putInt("fails", 0).putLong("lock_until", 0L).apply()
            return 0
        }
        val fails = prefs.getInt("fails", 0) + 1
        if (fails >= 5) {
            val secs = minOf(30 * (fails - 4), 600)
            prefs.edit().putInt("fails", fails).putLong("lock_until", now + secs * 1000L).apply()
            return secs
        }
        prefs.edit().putInt("fails", fails).apply()
        return -1
    }

    // ---------- Settings ----------
    var biometricEnabled: Boolean
        get() = prefs.getBoolean("bio", false)
        set(v) { prefs.edit().putBoolean("bio", v).apply() }

    /** Seconds in background before the vault locks. 0 = lock immediately. */
    var autoLockSeconds: Int
        get() = prefs.getInt("auto", 30)
        set(v) { prefs.edit().putInt("auto", v).apply() }

    // ---------- Vault data ----------
    fun load(): List<Entry> {
        if (!file.exists()) return emptyList()
        return try {
            val json = String(Crypto.decrypt(file.readBytes()), Charsets.UTF_8)
            val arr = JSONArray(json)
            (0 until arr.length()).map { Entry.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        val tmp = File(appCtx.filesDir, "vault.tmp")
        tmp.writeBytes(Crypto.encrypt(arr.toString().toByteArray(Charsets.UTF_8)))
        if (!tmp.renameTo(file)) {
            file.writeBytes(tmp.readBytes())
            tmp.delete()
        }
    }

    fun wipe() {
        file.delete()
        prefs.edit().clear().apply()
        Crypto.deleteKey()
    }

    // ---------- helpers ----------
    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)
}
