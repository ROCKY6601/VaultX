package com.vaultx.app.data

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class VaultRepository(context: Context) {
    private val appCtx = context.applicationContext
    private val file = File(appCtx.filesDir, "vault.bin")
    private val dekFile = File(appCtx.filesDir, "dek.bin")
    private val headerFile = File(appCtx.filesDir, "header.bin")
    private val prefs = appCtx.getSharedPreferences("vaultx_prefs", Context.MODE_PRIVATE)

    // ---------- PIN ----------
    fun hasPin(): Boolean = prefs.contains("pin_hash")

    fun setPin(pin: String, archiveOld: Boolean = false) {
        if (archiveOld) archiveOldBackup()
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("pin_salt", b64(salt))
            .putString("pin_hash", b64(hash(pin, salt)))
            .putInt("fails", 0)
            .putLong("lock_until", 0L)
            .apply()
        // (re)wrap the backup key with the new PIN
        runCatching {
            val d = dek()
            if (d == null) createBackupKeys(pin) else writeHeader(pin, d)
        }
    }

    fun verify(pin: String): Boolean {
        val salt = prefs.getString("pin_salt", null) ?: return false
        val stored = prefs.getString("pin_hash", null) ?: return false
        return MessageDigest.isEqual(hash(pin, unb64(salt)), unb64(stored))
    }

    /** 0 = correct, -1 = wrong, >0 = locked out, value is seconds remaining. */
    fun attempt(pin: String): Int {
        val now = System.currentTimeMillis()
        val until = prefs.getLong("lock_until", 0L)
        if (until > now) return ((until - now + 999) / 1000).toInt()
        if (verify(pin)) {
            prefs.edit().putInt("fails", 0).putLong("lock_until", 0L).apply()
            if (!headerFile.exists() || !dekFile.exists()) runCatching { createBackupKeys(pin) }
            return 0
        }
        val fails = prefs.getInt("fails", 0) + 1
        if (fails >= 5) {
            val secs = minOf(30 * (fails - 4), 600)
            prefs.edit().putInt("fails", fails).putLong("lock_until", now + secs * 1000L).apply()
            return secs
        }
        prefs.edit().putInt("fails", fails).apply()
        return -1
    }

    // ---------- Settings ----------
    var biometricEnabled: Boolean
        get() = prefs.getBoolean("bio", false)
        set(v) { prefs.edit().putBoolean("bio", v).apply() }

    /** Seconds in background before the vault locks. 0 = lock immediately. */
    var autoLockSeconds: Int
        get() = prefs.getInt("auto", 30)
        set(v) { prefs.edit().putInt("auto", v).apply() }

    // ---------- Vault data ----------
    fun load(): List<Entry> {
        if (!file.exists()) return emptyList()
        return try {
            val json = String(Crypto.decrypt(file.readBytes()), Charsets.UTF_8)
            parse(json)
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Saves privately and refreshes the encrypted backup file. */
    fun save(list: List<Entry>) {
        val tmp = File(appCtx.filesDir, "vault.tmp")
        tmp.writeBytes(Crypto.encrypt(toJson(list).toByteArray(Charsets.UTF_8)))
        if (!tmp.renameTo(file)) {
            file.writeBytes(tmp.readBytes())
            tmp.delete()
        }
        writeBackup(list, force = true)
    }

    fun wipe() {
        file.delete()
        dekFile.delete()
        headerFile.delete()
        runCatching { BackupStore.file().delete() }
        prefs.edit().clear().apply()
        Crypto.deleteKey()
    }

    // ---------- Encrypted backup (survives uninstall) ----------
    private fun dek(): ByteArray? =
        runCatching { Crypto.decrypt(dekFile.readBytes()) }.getOrNull()

    private fun createBackupKeys(pin: String) {
        val d = BackupCrypto.random(BackupCrypto.DEK_LEN)
        writeHeader(pin, d)
        dekFile.writeBytes(Crypto.encrypt(d))
    }

    private fun writeHeader(pin: String, dek: ByteArray) {
        val salt = BackupCrypto.random(BackupCrypto.SALT_LEN)
        val iter = BackupCrypto.ITERATIONS
        val wrapped = BackupCrypto.encrypt(BackupCrypto.kek(pin, salt, iter), dek)
        headerFile.writeBytes(salt + BackupCrypto.intToBytes(iter) + wrapped)
    }

    fun backupExists(): Boolean =
        runCatching { BackupStore.file().exists() }.getOrDefault(false)

    /** Moves an old backup aside (never deletes it) so a fresh start cannot overwrite it. */
    fun archiveOldBackup() {
        runCatching {
            val f = BackupStore.file()
            if (f.exists()) {
                f.renameTo(File(f.parentFile, "roth_old_" + System.currentTimeMillis() + ".dat"))
            }
        }
    }

    /**
     * force = false: skip when the list is empty and a backup already exists
     * (protects the backup if the private copy could not be read).
     */
    fun writeBackup(list: List<Entry>, force: Boolean) {
        runCatching {
            if (!BackupStore.hasAccess(appCtx)) return
            val d = dek() ?: return
            val header = headerFile.readBytes()
            if (header.size != BackupCrypto.HEADER_LEN) return
            val target = BackupStore.file()
            if (!force && list.isEmpty() && target.exists()) return
            val data = BackupCrypto.encrypt(
                SecretKeySpec(d, "AES"),
                toJson(list).toByteArray(Charsets.UTF_8)
            )
            val dir = target.parentFile ?: return
            dir.mkdirs()
            runCatching { File(dir, ".nomedia").createNewFile() }
            val tmp = File(dir, "roth.tmp")
            tmp.writeBytes(BackupCrypto.MAGIC + header + data)
            if (!tmp.renameTo(target)) {
                target.writeBytes(tmp.readBytes())
                tmp.delete()
            }
        }
    }

    /** Returns the saved items, or null if the PIN is wrong / the file is damaged. */
    fun readBackup(pin: String): List<Entry>? {
        return try {
            val bytes = BackupStore.file().readBytes()
            val m = BackupCrypto.MAGIC.size
            if (bytes.size < m + BackupCrypto.HEADER_LEN + BackupCrypto.IV_LEN + 16) return null
            if (!bytes.copyOfRange(0, m).contentEquals(BackupCrypto.MAGIC)) return null
            val salt = bytes.copyOfRange(m, m + BackupCrypto.SALT_LEN)
            val iter = BackupCrypto.bytesToInt(bytes, m + BackupCrypto.SALT_LEN)
            if (iter < 10_000 || iter > 2_000_000) return null
            val wStart = m + BackupCrypto.SALT_LEN + 4
            val wrapped = bytes.copyOfRange(wStart, wStart + BackupCrypto.WRAPPED_LEN)
            val d = BackupCrypto.decrypt(BackupCrypto.kek(pin, salt, iter), wrapped)
            val dataStart = m + BackupCrypto.HEADER_LEN
            val json = String(
                BackupCrypto.decrypt(SecretKeySpec(d, "AES"), bytes.copyOfRange(dataStart, bytes.size)),
                Charsets.UTF_8
            )
            parse(json)
        } catch (e: Exception) {
            null
        }
    }

    // ---------- helpers ----------
    private fun toJson(list: List<Entry>): String {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        return arr.toString()
    }

    private fun parse(json: String): List<Entry> {
        val arr = JSONArray(json)
        return (0 until arr.length()).map { Entry.fromJson(arr.getJSONObject(it)) }
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)
}
